/** 
 * 文 件 名 : UsersService.java
 * 版权：CopyRright (c) 2008-xxxx: 
 * 描述： 
 * 修改人： crazylion
 * 修改时间： 2013年7月14日
 * 跟踪单号： 
 * 修改单号： 
 * 修改内容： 
 */ 
package com.cst.service;

import com.cst.model.Users;

/**
 * @author crazylion
 *
 */
public interface UsersService
{
	public void addUser(Users user);
}
